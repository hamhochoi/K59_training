import Api

thing_global_id = 'a584ae49-24c6-4efd-b5b7-33d53cfc6f6b/binary_sensor.motion_detection'
item_global_id = 'a584ae49-24c6-4efd-b5b7-33d53cfc6f6b/binary_sensor.motion_detection/binary_sensor.motion_detection'
platform_id = 'a584ae49-24c6-4efd-b5b7-33d53cfc6f6b'
print(Api.api_get_thing_state_by_id(thing_global_id))
print(Api.api_get_things_state())
print(Api.api_get_item_state_by_id(thing_global_id, item_global_id))
print(Api.api_get_things_state_in_platform(platform_id))
print(Api.api_get_thing_info_in_platform(platform_id))
print(Api.api_get_things_info())



# import paho.mqtt.client as mqtt
# import json
# broker_address = "iot.eclipse.org"
# clientMQTT = mqtt.Client("test")  # create new instance
# clientMQTT.connect(broker_address)  # connect to broker
# global_id = 'f2b99574-8585-4cac-935f-d53ada871086/binary_sensor.motion_detection'
# message = {
#     'caller': 'collector',
#     'thing_global_id': global_id
# }
#
# clientMQTT.publish('dbwriter/request/api_get_thing_by_global_id', json.dumps(message))
# clientMQTT.publish('dbwriter/request/api_get_thing_by_global_id', json.dumps(message))
# clientMQTT.publish('dbwriter/request/api_get_thing_by_global_id', json.dumps(message))